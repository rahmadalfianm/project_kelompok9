<?php
$con = mysqli_connect("localhost", "id13098087_blacky57", "Achmad_Rheza57", "id13098087_hotel3") or die(mysql_error());

?>