<?php
$namaHost = "localhost";
$username = "id13098087_blacky57";
$password = "Achmad_Rheza57";
$database = "id13098087_hotel3";

$conect = mysqli_connect($namaHost, $username, $password, $database);
?>